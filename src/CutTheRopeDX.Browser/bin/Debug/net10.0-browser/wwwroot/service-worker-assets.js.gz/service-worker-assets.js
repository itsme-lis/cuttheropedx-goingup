self.assetsManifest = {
  "version": "JTj1jjbP",
  "assets": [
    {
      "hash": "sha256-zi7wNjxeLGCAmul0vP/X3vPrmpw88l2dKIW77O+AD98=",
      "url": "_framework/CutTheRopeDX.Browser.2wj6bfqkxf.wasm"
    },
    {
      "hash": "sha256-5iIA+LhYJ3JGKdiAfr5UYutJnB/6U4m5q49GP0+WB9I=",
      "url": "_framework/CutTheRopeDX.Browser.qfjqmiady2.pdb"
    },
    {
      "hash": "sha256-zoqI740s55ymBSa6XbuxZezBm/L3hrlPvJYT4iQI2/w=",
      "url": "_framework/CutTheRopeDX.Core.e1s9b91vmq.wasm"
    },
    {
      "hash": "sha256-d22LwjTJd3+rkVNi9W9WK7BTuKLSoUR13OPjN/f3yqY=",
      "url": "_framework/CutTheRopeDX.Core.x2u1koloxw.pdb"
    },
    {
      "hash": "sha256-P7qKvEHMowsS2wvBLOsl84cAPOho5yGcSqn3c4RfAWs=",
      "url": "_framework/Microsoft.CSharp.vc74ka0j2f.wasm"
    },
    {
      "hash": "sha256-BX/NSxLH9vLRxg5GuZdFrw4C/vcWnCCxbNZ7O0uVs6Q=",
      "url": "_framework/Microsoft.DotNet.HotReload.WebAssembly.Browser.jiityjz7hu.wasm"
    },
    {
      "hash": "sha256-SXjI4yVmFuxPXj5BFgLFvyJ2s+GEf0SzOJbLptFgNNs=",
      "url": "_framework/Microsoft.DotNet.HotReload.WebAssembly.Browser.pw7pg93i7q.lib.module.js"
    },
    {
      "hash": "sha256-AtC400vi85AY2+3JEyu7M0FZmzy5W/qPTQwnEYgE5WU=",
      "url": "_framework/Microsoft.VisualBasic.Core.ic4oks67r5.wasm"
    },
    {
      "hash": "sha256-QIQIVsgVtOjss3PhGWReXuYJqZfXWjj4Ka9g42s9/kM=",
      "url": "_framework/Microsoft.VisualBasic.oawltawhmj.wasm"
    },
    {
      "hash": "sha256-sWj2rJGGR2WaxEbYR4rTRr70SK107Yxg07dskgAB9Gs=",
      "url": "_framework/Microsoft.Win32.Primitives.n6ylnc1rdo.wasm"
    },
    {
      "hash": "sha256-LvXRTg75x2rR8pl0Bw85waJhB6rLFe8JUXJZHQVj1AA=",
      "url": "_framework/Microsoft.Win32.Registry.205yp9wx9t.wasm"
    },
    {
      "hash": "sha256-atHJ6DKl5yGFvGbR2tWZZa7RxFw+LDBpJQKmWjcZ3Wo=",
      "url": "_framework/SkiaSharp.i5h70vgwqp.wasm"
    },
    {
      "hash": "sha256-vz/SY7IT6HI0fgNQ8GZWZ+2a6G0TdNW8NiXfBQzCDFg=",
      "url": "_framework/System.AppContext.33lgp2bflw.wasm"
    },
    {
      "hash": "sha256-NBuJlJA0h3fyxW5UP4hoYInaEwe9OZxG2gEbjIdmCrY=",
      "url": "_framework/System.Buffers.g7kq07we8q.wasm"
    },
    {
      "hash": "sha256-IntDEoqraHR5cfj4BngQXlQjjlrcOYRCbXuQtRi06AY=",
      "url": "_framework/System.Collections.Concurrent.ayt23dc2he.wasm"
    },
    {
      "hash": "sha256-haf/04roddsE9PJPtNQ70GK4E5Pgdvs8Xn7GWtwiB8E=",
      "url": "_framework/System.Collections.Immutable.9nsqwhhu4t.wasm"
    },
    {
      "hash": "sha256-3Wp37kJjaV1lPseMx3LiVnPOb6jBbwgsqYQ5XifQfcI=",
      "url": "_framework/System.Collections.NonGeneric.525tw7pi7d.wasm"
    },
    {
      "hash": "sha256-H5J4UE+YDKwGT/+7eJ04nYWti5iFiGRcy+qc+mQi/O8=",
      "url": "_framework/System.Collections.Specialized.33r4c9ewf6.wasm"
    },
    {
      "hash": "sha256-TPWn1Sks7F7hYJ6yIoiF5E16QgcubEClSpnYJRxXog8=",
      "url": "_framework/System.Collections.gtdrkq93la.wasm"
    },
    {
      "hash": "sha256-lE1lvR0jcFeSBLguBCsrgQ6E/SwzEWSBo6DT1t+eyzE=",
      "url": "_framework/System.ComponentModel.Annotations.sojjklgz5l.wasm"
    },
    {
      "hash": "sha256-hlc54d9ROri0ue7K99r10i4zkATiLhcQ9zo0q7W2hR4=",
      "url": "_framework/System.ComponentModel.DataAnnotations.q8seqyww2r.wasm"
    },
    {
      "hash": "sha256-M/bTWUvIaq4cjgVjpzDowRr/CILOEX/94pdcYydLVIk=",
      "url": "_framework/System.ComponentModel.EventBasedAsync.7b6lvtlm4f.wasm"
    },
    {
      "hash": "sha256-93uWz5htHU4mW5eFYLizhbEpyIP7wRw7m5BxQpDfSkA=",
      "url": "_framework/System.ComponentModel.Primitives.nwih63pj9c.wasm"
    },
    {
      "hash": "sha256-uC84qHy9xx+jXRXst6IaM1xt/w7LxUiXTeriFG4ZAiA=",
      "url": "_framework/System.ComponentModel.TypeConverter.gq1uo9pwbw.wasm"
    },
    {
      "hash": "sha256-lEd4E48MsU5w1IehTBnjkEI2vNCXvuFPvPeMTyw3++U=",
      "url": "_framework/System.ComponentModel.gtzdp6gjij.wasm"
    },
    {
      "hash": "sha256-BnBG27W6TaVX+iCWFXq00o8F7GIIuUQtO0HkkMmwjMU=",
      "url": "_framework/System.Configuration.q733dci1qs.wasm"
    },
    {
      "hash": "sha256-AzhPOHmII8SXRU+N5orETTSLHfAesDlXNBoICnlf/hw=",
      "url": "_framework/System.Console.to0mbsovya.wasm"
    },
    {
      "hash": "sha256-CqRaluF8Fsi/jz9kCwltS3ZZ2H/dItSmY+6I8eMXh+4=",
      "url": "_framework/System.Core.azclj5c5yv.wasm"
    },
    {
      "hash": "sha256-O41AktxbWuV1VI6Jpdpn/SVaBfffTI9wPfARobgjWZ4=",
      "url": "_framework/System.Data.Common.nthckp9a3t.wasm"
    },
    {
      "hash": "sha256-ouu5ej3421SgXUzAYf44bxCQ7RUxrfwqwgmEwvh6k6A=",
      "url": "_framework/System.Data.DataSetExtensions.a9dlaxjhfy.wasm"
    },
    {
      "hash": "sha256-5GA1j3GuS3Q/muwMulPxIEys5V8jEFaVCDIho/UzAZ4=",
      "url": "_framework/System.Data.whqnroy0hk.wasm"
    },
    {
      "hash": "sha256-X5WU0oWl2MmZG7InLJHAf9o6jmX4ihpQpuZh/VxktlM=",
      "url": "_framework/System.Diagnostics.Contracts.1ocyilnve1.wasm"
    },
    {
      "hash": "sha256-qOE7MrpIyjV9RclZShTpxbW0dXN9NSp6E8O6BCM4j/k=",
      "url": "_framework/System.Diagnostics.Debug.0akkuosl4u.wasm"
    },
    {
      "hash": "sha256-Aqcp7AQ4SF2SidBLhSXGiBMx6wUGEmRGMUGtJuw5Biw=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.us3v4sw3re.wasm"
    },
    {
      "hash": "sha256-PShcf3L0QvoHeHX6WO3KQqAuMpM1dUIF3bOHwdvM02k=",
      "url": "_framework/System.Diagnostics.FileVersionInfo.52zf5lzwq0.wasm"
    },
    {
      "hash": "sha256-mnphv8xnpoUBaUm9xj1BKdq1ZtrmXgfNC1pTeUX8Z1A=",
      "url": "_framework/System.Diagnostics.Process.aksc3z10sf.wasm"
    },
    {
      "hash": "sha256-sM2dU4tKknoFqZJcmyFk/cQpUQVCrmiXLAqIvXTeHB4=",
      "url": "_framework/System.Diagnostics.StackTrace.oyhnn763kn.wasm"
    },
    {
      "hash": "sha256-OAmvIaAFxlBfLbdbPMsrpB3c+g8LVN0zOy07o5j5Flw=",
      "url": "_framework/System.Diagnostics.TextWriterTraceListener.4dqf2t866y.wasm"
    },
    {
      "hash": "sha256-cL64WwiWGdmdH0weZWJRZHKU7pWvR4JGCYHlGJGMroQ=",
      "url": "_framework/System.Diagnostics.Tools.4jmuc696pu.wasm"
    },
    {
      "hash": "sha256-+NGeFhqlXf6aE9U55il2yFOG92I2uTAw9V9l8WCD8+M=",
      "url": "_framework/System.Diagnostics.TraceSource.4djwg1x5dk.wasm"
    },
    {
      "hash": "sha256-KpCxa5K0+bU0W8TPjz8oJwyGdCZpA5ybxcUoEKh1zoA=",
      "url": "_framework/System.Diagnostics.Tracing.6xw2h3mehq.wasm"
    },
    {
      "hash": "sha256-/dvJgFicq8TLI4i4VdtMFPN1nKxit3i+vSbzahAe1cs=",
      "url": "_framework/System.Drawing.Primitives.fht3cwi9ck.wasm"
    },
    {
      "hash": "sha256-+Dy89WFcA7dUgn0g1UJ8TjdZZQ6V8ZN0kZfrRA8xGJ4=",
      "url": "_framework/System.Drawing.cby5s9a0on.wasm"
    },
    {
      "hash": "sha256-lm4ZND3nHWnLXcMzRKXz3I2BGdWPik99ttzib2RVCpw=",
      "url": "_framework/System.Dynamic.Runtime.yi4mxor0by.wasm"
    },
    {
      "hash": "sha256-M0vQyUCJLFCrFQX/Bg7bPG8nfXfxjvEYTseZkbfGYxg=",
      "url": "_framework/System.Formats.Asn1.56jjdsv3d0.wasm"
    },
    {
      "hash": "sha256-xAroer71Mir0OA4S5cPejkZaL03TqTFg1aimzQ9LIok=",
      "url": "_framework/System.Formats.Tar.89bpoq7vrz.wasm"
    },
    {
      "hash": "sha256-zZUFwm7oGVSq1qsK8oIZuzSLLXjmcoLgT1iy5qqXHp8=",
      "url": "_framework/System.Globalization.Calendars.rildgn7mzz.wasm"
    },
    {
      "hash": "sha256-9HWY1aCFc5GoQcysEA0v85vU5i8CRuqZvKqJJpzka6k=",
      "url": "_framework/System.Globalization.Extensions.opr37tm2pn.wasm"
    },
    {
      "hash": "sha256-qnMi2/9zgAiBieR/7gLp8ZIASS2EbKk5F3FK/ZFHXn8=",
      "url": "_framework/System.Globalization.moqtkrs3kx.wasm"
    },
    {
      "hash": "sha256-2mhUJF3wl9QgdsvbtOy/ZDArJeyj8crmASfCqaGAtNw=",
      "url": "_framework/System.IO.Compression.6pdq5v22pd.wasm"
    },
    {
      "hash": "sha256-CZooa2KeN4jmRIpQK41QSkQP6d4dmj++PSm0FlRGkuo=",
      "url": "_framework/System.IO.Compression.Brotli.7ohel80nih.wasm"
    },
    {
      "hash": "sha256-clgAvPC5qyl4EnAE8n7NPNbEX9+Y4Rpxpnxl5349y+4=",
      "url": "_framework/System.IO.Compression.FileSystem.y83oisb571.wasm"
    },
    {
      "hash": "sha256-uzfss5y8PFTeOVFAKk+jQLi/FLPKrehaUq6f+1xqeoQ=",
      "url": "_framework/System.IO.Compression.ZipFile.tmxcz8z1z1.wasm"
    },
    {
      "hash": "sha256-A0JUayiM8+PP3INOm0TFut8IWKzKDe4PcEZGksJchHU=",
      "url": "_framework/System.IO.FileSystem.AccessControl.xzbtcseu3i.wasm"
    },
    {
      "hash": "sha256-NPFQq5Ilvv6t6twDWNjv6zmCVVMv4GREj5xvBqMG71g=",
      "url": "_framework/System.IO.FileSystem.DriveInfo.g3te4cd6dq.wasm"
    },
    {
      "hash": "sha256-rJF209xyy75EKtaVFIXszQG504rNkNMzn5nuQgopOis=",
      "url": "_framework/System.IO.FileSystem.Primitives.s8z1h6e7bs.wasm"
    },
    {
      "hash": "sha256-+1GYGl6rYRxD2mfq9jYmM71NOi5lVQ4ntSd2XgLQr/A=",
      "url": "_framework/System.IO.FileSystem.Watcher.jia322rvtg.wasm"
    },
    {
      "hash": "sha256-vjhZDTZZmOeM6kiHpKghpt2WLmy8+s51jgU3nWVoMsQ=",
      "url": "_framework/System.IO.FileSystem.y4d3mjm0rs.wasm"
    },
    {
      "hash": "sha256-12gqkUA+EW9Ok+XjNnztHbwcZdF0sHGfYsGFDhkaJHA=",
      "url": "_framework/System.IO.IsolatedStorage.vucb3c4eed.wasm"
    },
    {
      "hash": "sha256-YGcvm9Unqx7Nslxy7M0XGAICX/34Ac4rHJ1GgryesTc=",
      "url": "_framework/System.IO.MemoryMappedFiles.slhu4kxyuf.wasm"
    },
    {
      "hash": "sha256-D2zGD+7FWanAQkGdcxPpzhuAqr1TBe3FwbCzyOEeDDc=",
      "url": "_framework/System.IO.Pipelines.d9mh1mhl6a.wasm"
    },
    {
      "hash": "sha256-wlyNSMlOoSLtBjH4ahAIRUF/EIraBRKRS1mqdDW1BEc=",
      "url": "_framework/System.IO.Pipes.6axf1j8g7w.wasm"
    },
    {
      "hash": "sha256-sqt6fPu+tFpCJkBRmzTwCeFxWuNkv9Qvw6RRdtyLi/Y=",
      "url": "_framework/System.IO.Pipes.AccessControl.aawhalzgje.wasm"
    },
    {
      "hash": "sha256-141FexMM+rgyJjbPV3Tqjins7IWx6QuAhdpWiGB8+wU=",
      "url": "_framework/System.IO.UnmanagedMemoryStream.jtjypz1bw3.wasm"
    },
    {
      "hash": "sha256-TrxbGqQLHCo+lECXU34H+9JxDj+EGVrjMrSa4JIhTpQ=",
      "url": "_framework/System.IO.u03kcd51u2.wasm"
    },
    {
      "hash": "sha256-kqYBPZyPoXxShJfn6Z4etPhqhi7wXEdqUL+YvjNrMa0=",
      "url": "_framework/System.Linq.AsyncEnumerable.qecnowng39.wasm"
    },
    {
      "hash": "sha256-hJy4f+HmGU4Xh4kza5OapM/UfFxlTnF0arbzmWUqEPM=",
      "url": "_framework/System.Linq.Expressions.48ueoty928.wasm"
    },
    {
      "hash": "sha256-MgAUM4mdUmMKSpa9kowpy8pfI5inqZyMsDmFDZYeKFU=",
      "url": "_framework/System.Linq.Parallel.6f9mb35gje.wasm"
    },
    {
      "hash": "sha256-d0dArG+pt8tZXMUGpFhpI18ztIMnH4waXkZ6KsKhqEI=",
      "url": "_framework/System.Linq.Queryable.bv9ee87bon.wasm"
    },
    {
      "hash": "sha256-y8xCXRiQfpwTV3uVD+XU9IZyYOBV3IUhbEzI8/FlECQ=",
      "url": "_framework/System.Linq.ffyao6dtjo.wasm"
    },
    {
      "hash": "sha256-Sg0IsbGxUOdZ+8GEG2rO5+mJutwVXDv/c3DWvC0Y1LM=",
      "url": "_framework/System.Memory.i6uetwkqik.wasm"
    },
    {
      "hash": "sha256-R42oDv3s94KCE4lozGAQ19Wa5RpsPf0UyE2KXiTvME8=",
      "url": "_framework/System.Net.Http.9odm4o2yfw.wasm"
    },
    {
      "hash": "sha256-ZYX5QZNYs9FBGbSqFOEHB1CSxj2o3HZlYgB+H8dfls8=",
      "url": "_framework/System.Net.Http.Json.lkg2pjap28.wasm"
    },
    {
      "hash": "sha256-/e2K/6DbHfR5WYWSWPEyXxwbwdeGUtCBfIxY3PyKhaI=",
      "url": "_framework/System.Net.HttpListener.l269ngb85c.wasm"
    },
    {
      "hash": "sha256-B/+5emPbFkpK82pnJSnAmTzRuY7KRKi7wvTfFnULfh4=",
      "url": "_framework/System.Net.Mail.7s5j7d2u11.wasm"
    },
    {
      "hash": "sha256-Ui9OtscoCa7Rn+R6uggcz2M7ywzHL64xb5x7hqyrRl8=",
      "url": "_framework/System.Net.NameResolution.y3a25frvkb.wasm"
    },
    {
      "hash": "sha256-ej7w2CMrRXME9AFCOPRuLwPTCNJ5MfZYGaGYL4xpwiU=",
      "url": "_framework/System.Net.NetworkInformation.6hh4xfj68d.wasm"
    },
    {
      "hash": "sha256-Me8xKvJFcpGmQz0AsV1c2r9vpfCIAUEvRS8wXBIlB8s=",
      "url": "_framework/System.Net.Ping.blplcg5q7j.wasm"
    },
    {
      "hash": "sha256-I7jNDlc6aY2jmzdqNKjL/MZtDTu9OXjmsPD4nXyeFio=",
      "url": "_framework/System.Net.Primitives.52l52f7ge8.wasm"
    },
    {
      "hash": "sha256-WqNOpml+SO8zGljApjO78PEvcIFKqDWK0LVTSKsFxIA=",
      "url": "_framework/System.Net.Quic.aw952wuprs.wasm"
    },
    {
      "hash": "sha256-KFXJT6HgrkCQDdxsNE6gg+fQHpN4MfAkgt3h6YXYvbM=",
      "url": "_framework/System.Net.Requests.k1mlkdyp0u.wasm"
    },
    {
      "hash": "sha256-l4OlxqQwu+sYhjLriuJSuMwHNJ+r/BGVrXp92H+S3NQ=",
      "url": "_framework/System.Net.Security.vm6w2umju9.wasm"
    },
    {
      "hash": "sha256-rlq89aqpXUJXWQVg3RSoAJlvCpD0wwttk75XFhW7Bps=",
      "url": "_framework/System.Net.ServerSentEvents.adh3kntjlv.wasm"
    },
    {
      "hash": "sha256-4Zv++S2GQBCLLKZxZWQfRW3vgfFi9iddABhfC0/YyoM=",
      "url": "_framework/System.Net.ServicePoint.v8e4bui0ea.wasm"
    },
    {
      "hash": "sha256-E0uMfyK7c1v52Ax4PT7Al8rOKXtImY4piCmVV1h36sA=",
      "url": "_framework/System.Net.Sockets.ts6iauk88c.wasm"
    },
    {
      "hash": "sha256-bBhkM6WRjt9KHqN/yR59aCMpgcg5lxrlHszjVilE9h0=",
      "url": "_framework/System.Net.WebClient.od0uvbnjit.wasm"
    },
    {
      "hash": "sha256-hoFgNcO9TCczLQwT6qI84eb3J3qaSt95k4Jk1T6d4G8=",
      "url": "_framework/System.Net.WebHeaderCollection.qf50eeagye.wasm"
    },
    {
      "hash": "sha256-6k7n9kRTIjsvj7OlfcaAt7JtbA1BYzx/krXVj9B2al8=",
      "url": "_framework/System.Net.WebProxy.iavyox40gr.wasm"
    },
    {
      "hash": "sha256-jknBfKz+BaTegYBkGof7b0J6y4A2yMaaO9A7SYAq0XY=",
      "url": "_framework/System.Net.WebSockets.Client.qeq362432l.wasm"
    },
    {
      "hash": "sha256-MK9DXHHm6AKhF5Je0S8xPCHgY0e0z4i+GMJ6TMhNOoI=",
      "url": "_framework/System.Net.WebSockets.oek2p1up7o.wasm"
    },
    {
      "hash": "sha256-7uRJ8dcmw3n7qTbvh1xPYnY0vmPYLapuPLmNF0k4e8I=",
      "url": "_framework/System.Net.i47gzsagt6.wasm"
    },
    {
      "hash": "sha256-3xe0W+JmwQNNagoBuTG5UEUhgmotX8PmdKsPci5JnPA=",
      "url": "_framework/System.Numerics.Vectors.n63j92lpq0.wasm"
    },
    {
      "hash": "sha256-y32dbXS60w1HfL97xSaaoig78fCA2hQirSUfe9ZGl30=",
      "url": "_framework/System.Numerics.rkirn4ewf6.wasm"
    },
    {
      "hash": "sha256-EoCxZODvWTOXgxLrSIGtMa2yjMKLeeK1JlfMuIAfMbc=",
      "url": "_framework/System.ObjectModel.i378yy84uu.wasm"
    },
    {
      "hash": "sha256-Zo7KLnYA4xy8mxDzssMreXZfTlHBgRKnLWfYFMiQvCw=",
      "url": "_framework/System.Private.CoreLib.acqhqif0l6.wasm"
    },
    {
      "hash": "sha256-SKiQcTZvy/3E4yYZXbAuxojifAxqCAALhFducmouT7M=",
      "url": "_framework/System.Private.DataContractSerialization.sny9oej0eg.wasm"
    },
    {
      "hash": "sha256-LunJHkRu5RgV5fHjx5eDdT17J4Gtytr6/oKJwO1d8R0=",
      "url": "_framework/System.Private.Uri.esflyl9tnu.wasm"
    },
    {
      "hash": "sha256-EjZ9rzHEnY68PXt05q3B/kbsekIDstXc7Sn5XRDvk1E=",
      "url": "_framework/System.Private.Xml.Linq.memmbl9fkq.wasm"
    },
    {
      "hash": "sha256-Mx0L0SdPw6FcjUMwHIOX5eE8YOVQ6jMFlrmRiK+KkhQ=",
      "url": "_framework/System.Private.Xml.zw12n4yipy.wasm"
    },
    {
      "hash": "sha256-z8vs8oc+dKapwTQeJ57oDBrsDsHLYwVv3iVtzebNxZo=",
      "url": "_framework/System.Reflection.14urzokzzb.wasm"
    },
    {
      "hash": "sha256-T0nAzwQ4akMO9XJb2cgIhZsnc78p2+fxtnVD40l1XA4=",
      "url": "_framework/System.Reflection.DispatchProxy.3vrt3hlgt3.wasm"
    },
    {
      "hash": "sha256-eS8SCSrXQiex2kgp1qxb8IRQqdqTozoZXpt+CoM5v1U=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.ng7j4cz770.wasm"
    },
    {
      "hash": "sha256-B9LTebLgF9ZAw2P8ct6U1bZ5++SFfNBBam+PO4a4ELo=",
      "url": "_framework/System.Reflection.Emit.Lightweight.v2imlilbpe.wasm"
    },
    {
      "hash": "sha256-jrKQzTgqMdjuqWHUGsPfnCbqnWpXQkvKfDfBSM+Mt0g=",
      "url": "_framework/System.Reflection.Emit.udsnuk3ij6.wasm"
    },
    {
      "hash": "sha256-P2Qk2OLacQqt2Llp1r47hyo48QLV06MpAlAZXa35u8c=",
      "url": "_framework/System.Reflection.Extensions.182qm6arqh.wasm"
    },
    {
      "hash": "sha256-TYUTGCId0GxyLd2Jv9MzjCaGIiyVHaCQ9dFDARceTQA=",
      "url": "_framework/System.Reflection.Metadata.5mrm43mmwy.wasm"
    },
    {
      "hash": "sha256-ehYMFAYAGb49ZR5SbH909AXh3SHOi+60MV9aTsA4eNc=",
      "url": "_framework/System.Reflection.Primitives.2qdwh2ddjb.wasm"
    },
    {
      "hash": "sha256-bKXQADwSKixye7MZzqGBpXSYCeCyp5ReO68y4cVZsnE=",
      "url": "_framework/System.Reflection.TypeExtensions.ohzfghpj7u.wasm"
    },
    {
      "hash": "sha256-HN9FyXSEtGpwrjaWYqr0BYnAF5LhvVg5YyAOfj59K/w=",
      "url": "_framework/System.Resources.Reader.o5l4jqwkcn.wasm"
    },
    {
      "hash": "sha256-4sISLJ4CC3eWntk5TFLGQP39skJD43fZt2tHEKDrQ7w=",
      "url": "_framework/System.Resources.ResourceManager.u0kj92um25.wasm"
    },
    {
      "hash": "sha256-x+TbpI+502ck5N3QVtiTNFvaRmEzfM6AUQezqym5L34=",
      "url": "_framework/System.Resources.Writer.fybhus075b.wasm"
    },
    {
      "hash": "sha256-vtZgLdKVZ4XAh9LNuAg07pdJWav2ZTSdji3wBl6Tnak=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.a2v8uztr6q.wasm"
    },
    {
      "hash": "sha256-NWO0niQAT2U38QP2p678YrYceWxfcGZiao7o4SRm/lI=",
      "url": "_framework/System.Runtime.CompilerServices.VisualC.h9ibm7eot2.wasm"
    },
    {
      "hash": "sha256-sGE96dH2hSZ2o95KQyX/KhuQGnsAFEHdXfHf2rJrSYY=",
      "url": "_framework/System.Runtime.Extensions.oueezzziy7.wasm"
    },
    {
      "hash": "sha256-r9JfKdsE92m/EaS+G9TnZ8alLJ37y9loMJDwpuhyt/4=",
      "url": "_framework/System.Runtime.Handles.pegxo55rww.wasm"
    },
    {
      "hash": "sha256-r2gFCA+pgFEb2L9UVD2ikpc1TLVxMjWdkQeuSoAnsdk=",
      "url": "_framework/System.Runtime.InteropServices.76dk94nxht.wasm"
    },
    {
      "hash": "sha256-i0mCdwRLNy+fsELohj+iSdXW5CsN1dlkMsDHnTJw5sM=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.11d6720mn8.wasm"
    },
    {
      "hash": "sha256-+QFSX4Pa6oEemBGAbLSx6ddeliBDgepZ+wpUyQqPbsw=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.himsthc3a6.wasm"
    },
    {
      "hash": "sha256-w6hLmBdElU3LjlQ9rQqwli8s0kgF20g9OJ+9AbS+AZw=",
      "url": "_framework/System.Runtime.Intrinsics.pxgyd8cnpl.wasm"
    },
    {
      "hash": "sha256-nL05yWh/sEH+UGtqYaYsoxnQbkeZ2wfZIJdSlMdUVuU=",
      "url": "_framework/System.Runtime.Loader.smrevcdjv4.wasm"
    },
    {
      "hash": "sha256-qAA+g2R9BL+KkiVw/uSdgBzcMyh6lHjvE8btAPFlf44=",
      "url": "_framework/System.Runtime.Numerics.c79r80p0xa.wasm"
    },
    {
      "hash": "sha256-8UOlvjQNeuJCJVs/80yedxgANKXEv+u783ZjeVX9lxA=",
      "url": "_framework/System.Runtime.Serialization.Formatters.5nvzlh22y8.wasm"
    },
    {
      "hash": "sha256-9PvflPMpTgXt/CJr9aPaMFxrcfb9dfyCWfQcHjBZ/Lw=",
      "url": "_framework/System.Runtime.Serialization.Json.4u1byp8ddu.wasm"
    },
    {
      "hash": "sha256-CK47ivfrIuMw7yupuqFV24kdTeMPxzka4edYB/BUK9I=",
      "url": "_framework/System.Runtime.Serialization.Primitives.0677mizgg8.wasm"
    },
    {
      "hash": "sha256-1ZF5POZglEr7ftw2T6suEvJDtXBOaTWjwiFNqHM6A14=",
      "url": "_framework/System.Runtime.Serialization.Xml.7t5vv8ymb3.wasm"
    },
    {
      "hash": "sha256-2VvOlAvLHV9Hmwglfi2ZMv/OBChHICovaG0z7JoV4/s=",
      "url": "_framework/System.Runtime.Serialization.xyb15dfsu9.wasm"
    },
    {
      "hash": "sha256-sz8dIFsswef1k1Xw7c0y0c+hKmO4ytyw9WoY17i+cAU=",
      "url": "_framework/System.Runtime.p5wq7tenlq.wasm"
    },
    {
      "hash": "sha256-t/Zhd+N29fKKAil705KO0KB8ytqtRMQ2gIUgle8vQxU=",
      "url": "_framework/System.Security.AccessControl.9gsd8k6c5m.wasm"
    },
    {
      "hash": "sha256-JcfUg2gv1aAcLpXhGHpawjy/Te3Qg9fcheHexSFJsec=",
      "url": "_framework/System.Security.Claims.l0ljqfaxwo.wasm"
    },
    {
      "hash": "sha256-asDjhVEPO/QN5eJuPJXMjymopyT1voLEIPbRMo6SpJM=",
      "url": "_framework/System.Security.Cryptography.2ufhqnonzh.wasm"
    },
    {
      "hash": "sha256-4vLqnvj48uhFTeNavhXSPLej8+a04vT4Q4BzeA7aOJc=",
      "url": "_framework/System.Security.Cryptography.Algorithms.i0xv6lwo7z.wasm"
    },
    {
      "hash": "sha256-2sUCiaSAJyXHG/+fD4xucBGmWPzXRTVKmMn/tpyrwMs=",
      "url": "_framework/System.Security.Cryptography.Cng.eeehrv0scy.wasm"
    },
    {
      "hash": "sha256-vjBPq4f54O+P5zvokIBJUwXcSpez9Y+PGc0wtzqW6W4=",
      "url": "_framework/System.Security.Cryptography.Csp.2c9gox8ebd.wasm"
    },
    {
      "hash": "sha256-Ypo7uNzxzTGJIC9jT/m/b4kN4txarBQHeb5H9RXu54k=",
      "url": "_framework/System.Security.Cryptography.Encoding.axny8s8hqs.wasm"
    },
    {
      "hash": "sha256-gaDsyTJrtp4XzQYUXgmfB6RLIGi2FjWj8Ar3P9WDT/4=",
      "url": "_framework/System.Security.Cryptography.OpenSsl.1sxm4ayhhy.wasm"
    },
    {
      "hash": "sha256-8LydFSbE7V5LdD50fXdpmeIt/m2sksGJqzMY5e6vP4Y=",
      "url": "_framework/System.Security.Cryptography.Primitives.4ri0a9h1v4.wasm"
    },
    {
      "hash": "sha256-aWvCLknwVe+mKmgXO2xDc5IhC7B6PLDmWOFFf933b/o=",
      "url": "_framework/System.Security.Cryptography.X509Certificates.rncai5fzz3.wasm"
    },
    {
      "hash": "sha256-ReXTuJnKsfUr67WZ7ekLkKwdCADP7MLsv5+8Rz9kUbM=",
      "url": "_framework/System.Security.Principal.1tjw5xr7f1.wasm"
    },
    {
      "hash": "sha256-aUJqbqjVpUgPNm/I10ZI5tTZvdAHZuXZHM1+bgtEh2Q=",
      "url": "_framework/System.Security.Principal.Windows.9gaajfy1mm.wasm"
    },
    {
      "hash": "sha256-XWsfTgbMvq8bIErWG9SRS12GjUA70gfii8Zn1x06wo4=",
      "url": "_framework/System.Security.SecureString.hbgjudeeg7.wasm"
    },
    {
      "hash": "sha256-xlJkQOl9i3U3R0rHBnv42WUyxpyTfb4NWeQP9thvn8k=",
      "url": "_framework/System.Security.ua0hvadql2.wasm"
    },
    {
      "hash": "sha256-EoKhlu6LFf/rxXLNN0AG/ox3cVZSQZcoJHRMn3Ai3ZM=",
      "url": "_framework/System.ServiceModel.Web.a5nn12k2du.wasm"
    },
    {
      "hash": "sha256-kt3OXJkHVIZ0HaKa/O5mKV/gKK2VRUPUcZlR1mMEWqI=",
      "url": "_framework/System.ServiceProcess.mzhiaa0o9m.wasm"
    },
    {
      "hash": "sha256-fxt6zzGzOdxcGfVxV+shFrqbQSKxSfGJNB7/GqvLsB8=",
      "url": "_framework/System.Text.Encoding.CodePages.fso8gniga6.wasm"
    },
    {
      "hash": "sha256-N/7bmYLlo54Cs+Dw8ee7CkFrLzqTe8izc5vm6dvzizM=",
      "url": "_framework/System.Text.Encoding.Extensions.jth4fv0ujc.wasm"
    },
    {
      "hash": "sha256-RybkW+87HvDCrKwpsSLXM3w5TB5EMz7dpLJz1o+fFaI=",
      "url": "_framework/System.Text.Encoding.hen1lijr2s.wasm"
    },
    {
      "hash": "sha256-ZAoPykd2oHgSQyIJbM0ktKOTvV6mh7f8h4Ev8xRgPJk=",
      "url": "_framework/System.Text.Encodings.Web.s63xwzfs6e.wasm"
    },
    {
      "hash": "sha256-ZhbF4R3Uf6o3EptGsHICrb2qcZ2bd1UEGfHtMc+VkxY=",
      "url": "_framework/System.Text.Json.e68ojdl57q.wasm"
    },
    {
      "hash": "sha256-zN+88osSOmhdIdVgihibx/x1XedKWsCYEgvtcYvxypY=",
      "url": "_framework/System.Text.RegularExpressions.o5g45g5kfe.wasm"
    },
    {
      "hash": "sha256-w+LhmzUpdAZw6jVH9FdmsnN/n9z3LtLHTZR6pyxGSzg=",
      "url": "_framework/System.Threading.AccessControl.vdpdtl3x6u.wasm"
    },
    {
      "hash": "sha256-7JYMWtx5aaztvI6qsJStob8sRMLyMrT6oDNkD24Inaw=",
      "url": "_framework/System.Threading.Channels.wty3mw4oue.wasm"
    },
    {
      "hash": "sha256-nAsVVeqQDNVR0DaIhT//1tZcxyCxt6LUsnXjhz9mevo=",
      "url": "_framework/System.Threading.Overlapped.03j0f78xbg.wasm"
    },
    {
      "hash": "sha256-h4ITo++VVySJB9UXW1AizkqXGbRc7hysEJPM8paCQBQ=",
      "url": "_framework/System.Threading.Tasks.Dataflow.1qphddued4.wasm"
    },
    {
      "hash": "sha256-Pgd/40O6xPGNbTDdtZ7IXhjog5u+uiSnSeblax0Kd2w=",
      "url": "_framework/System.Threading.Tasks.Extensions.a6m6fd88nw.wasm"
    },
    {
      "hash": "sha256-sUxZoPUOtigPLyVhliXgQ79G8wxA8VXhlK86oWh8RhU=",
      "url": "_framework/System.Threading.Tasks.Parallel.hwicu9gnb7.wasm"
    },
    {
      "hash": "sha256-ZAZ/8IqOgKMUtbsFNyZ/nGPxSrgnh8t4h5Z+SVjecyY=",
      "url": "_framework/System.Threading.Tasks.ko7yntasn6.wasm"
    },
    {
      "hash": "sha256-poEtzjS5NNRnotBgaKA2Su+mjp8Y0eXTf7yoYasFvAQ=",
      "url": "_framework/System.Threading.Thread.ydz2qayyqe.wasm"
    },
    {
      "hash": "sha256-ELorBXMa++9uTr6P3crPiAaJMWcEhNok01GvE1QPjjs=",
      "url": "_framework/System.Threading.ThreadPool.4f7y4725hj.wasm"
    },
    {
      "hash": "sha256-spGH+vGozMmLNWcgCowJHX/L9fBEdoHOEveQK9OdmxI=",
      "url": "_framework/System.Threading.Timer.23ma43391f.wasm"
    },
    {
      "hash": "sha256-XwK+Pb+6p1iYXhc2Ks+FjDwPBgIInT2jAWOQ1jEQsNM=",
      "url": "_framework/System.Threading.xg0tuqpte9.wasm"
    },
    {
      "hash": "sha256-DwZ5kQKS8S//BhRIzWNpCBtH7PWn1RUGmLKfunzItyI=",
      "url": "_framework/System.Transactions.1k679dq1nh.wasm"
    },
    {
      "hash": "sha256-/etlP37Z3fbLkp3G+SuI8t2EuBlW6ArNkc821ii6YrU=",
      "url": "_framework/System.Transactions.Local.vhgy89wfp9.wasm"
    },
    {
      "hash": "sha256-yGHllPKjSV7O8dufUyuOGmky/GbwzH0IlPDpgsfuZG4=",
      "url": "_framework/System.ValueTuple.gm53bht7l7.wasm"
    },
    {
      "hash": "sha256-b150ZISvFUH8voYwQdhIH/m8vkHcJFY+LFDfuemZ2sw=",
      "url": "_framework/System.Web.HttpUtility.xg7fizhwzt.wasm"
    },
    {
      "hash": "sha256-PADclgEUTNPtXvaKE9YgE1DRcW/Q+gPLdwMUsbu8esA=",
      "url": "_framework/System.Web.sakoricpi1.wasm"
    },
    {
      "hash": "sha256-mWvSjccrBX09Q7oIJzRGJIi6zQl0pJMKkSrWN9kWf6Y=",
      "url": "_framework/System.Windows.98z5iu2ekq.wasm"
    },
    {
      "hash": "sha256-FM7him4hRwYj3b/rUlLVoDuzrDlojL6J1pMTiiv+prk=",
      "url": "_framework/System.Xml.Linq.4w1i83kr6d.wasm"
    },
    {
      "hash": "sha256-RPbWKMyF0PcAToP99SZP3iI1LbK+2mMn0hPGIrJuwMI=",
      "url": "_framework/System.Xml.ReaderWriter.gt2wkfrpd2.wasm"
    },
    {
      "hash": "sha256-OtgEHFA+kC4Og+9sy9AItDeN0G36r5KKP80acvekmKQ=",
      "url": "_framework/System.Xml.Serialization.ymsdqvtcj5.wasm"
    },
    {
      "hash": "sha256-hVjT4ogBaijnAej8Jkvvfi/3R1Sz65EOhwcQavaAH8I=",
      "url": "_framework/System.Xml.XDocument.nthxjrhml8.wasm"
    },
    {
      "hash": "sha256-Sh41QbA3ENHi4CfpbioGcvLy8HrcPA2WVz/gL9fH5lA=",
      "url": "_framework/System.Xml.XPath.XDocument.64udcjx5rc.wasm"
    },
    {
      "hash": "sha256-zjcKkw6BNuo0vSx0rlxPlbNuoXjUPWYT9Q1xX548wAU=",
      "url": "_framework/System.Xml.XPath.m6ukudree9.wasm"
    },
    {
      "hash": "sha256-WkzkDq1p5Hr8baeIcyUvZkqCz0Qtl39PQvxQVm0EQkA=",
      "url": "_framework/System.Xml.XmlDocument.uqap183j3j.wasm"
    },
    {
      "hash": "sha256-7M5Yf1qrKhJZ1ts2o6P73IDZwOinWT1m/rX9xwhvX18=",
      "url": "_framework/System.Xml.XmlSerializer.kyxgnik2yp.wasm"
    },
    {
      "hash": "sha256-QJsL5vasxIwvmlNTlOtLvB4u9y1eFnTzQk9qyIkunDo=",
      "url": "_framework/System.Xml.gccv71ojjn.wasm"
    },
    {
      "hash": "sha256-UvzF6QRtJEhekaFpn7/fdSo6I77TIVOQYu+B0IvKLAw=",
      "url": "_framework/System.q2zv1ajo7g.wasm"
    },
    {
      "hash": "sha256-JUj0SUenc5aNsprOIJomnkeHQU0zOM9KnaF9DBYp5as=",
      "url": "_framework/WindowsBase.nd3r6urbkm.wasm"
    },
    {
      "hash": "sha256-crxxqB+poYTPsUDUwSmfjlpdjkILlqp8mjXXaAFKoaU=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-gkQ8GxkWyh0BLme64OuSZ0ABha5f8RfJ8n5+z0SaOJI=",
      "url": "_framework/dotnet.js.map"
    },
    {
      "hash": "sha256-cLErJ6cfGnvzhQzzFTXiMZUsEEtOxEMXfAVEPcxdyY4=",
      "url": "_framework/dotnet.native.ctzto7ithw.js"
    },
    {
      "hash": "sha256-d52HOOLK0qy8LtoWY/OeBSGONrd9Hz7CoktVo6G0WcA=",
      "url": "_framework/dotnet.native.lpfkuug7de.wasm"
    },
    {
      "hash": "sha256-R+0xdNwpy+5IpVl6ddVip5KCAP2fqy/QdeDY3/sEvoc=",
      "url": "_framework/dotnet.runtime.js.map"
    },
    {
      "hash": "sha256-MZMguyke9CroSQl+L/SHIGFkPTD+LtYGXkXjAvwWx40=",
      "url": "_framework/dotnet.runtime.zbexyp8zrs.js"
    },
    {
      "hash": "sha256-L55XGcSlCWjg/nPH8pqX4FoLUqcw89+V7xgu0GWwKSU=",
      "url": "_framework/mscorlib.l31p083pc1.wasm"
    },
    {
      "hash": "sha256-ANBTDvID1f1UUcJOBmDfE5tFVLna1UUVAxMEbtfGiRM=",
      "url": "_framework/netstandard.8ql06rx5ae.wasm"
    },
    {
      "hash": "sha256-Pw0kYiFU1fkJ4mg//OBJiyfjh+zMXGNCvRoU0ODV8xk=",
      "url": "audio.js"
    },
    {
      "hash": "sha256-ldKaqg3XY86879DXDekFF2/Xi+B7mgNrrPVJs1yUT28=",
      "url": "cursor.js"
    },
    {
      "hash": "sha256-DViSrZsMM4VH9Qxfvv6JNVGxkXdZfSthOeIBCnaxtjA=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-fRtHkT3Y0D85vcFsarrlOZYFx5iN4u+TygozHYrLvT8=",
      "url": "fetch.js"
    },
    {
      "hash": "sha256-T8nrOK73rg6JcxrVnM8bzVutiOkJhhNQWLq7ZLKyp1I=",
      "url": "glcontext.js"
    },
    {
      "hash": "sha256-oC2P2BHWnGFJOM43jTOrCArf5nrpe75/z4sQGfGaxsM=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-lvKDIsnSwl3yEbl1C5lfEgUj9gxkUP17Iwxpu7vXwB0=",
      "url": "index.html"
    },
    {
      "hash": "sha256-3WTe4Nnj2EpnzBlznO1whmj+vNW16nxvwnBKlbVaOKs=",
      "url": "loading-progress.js"
    },
    {
      "hash": "sha256-te3LJp6CS/wcfbcZsvW7bkqmAYa04GT4vdtm9UMyTEM=",
      "url": "main.js"
    },
    {
      "hash": "sha256-AxNM7kcbYo9J5HFB5fCvX4xlGi4lqjxBeMis+fkA6Y8=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-QTbpO1mBxgYyp6dHWXzA3bI7a9KWIxivv1zMxCySuIY=",
      "url": "pwa.js"
    },
    {
      "hash": "sha256-pFgVqCji/xPcL6oP88AZq42bBrKGrctAj+5wTO1nBVQ=",
      "url": "service-worker.js"
    },
    {
      "hash": "sha256-Ct/AaLsiRaIsrjjZrI56r1EAN3ztLIpctChwHnfY0Eo=",
      "url": "service-worker.published.js"
    },
    {
      "hash": "sha256-0+4pfKVaIVbK/CoIUXQ4VOd0YCtopsty7orDHzuSyC0=",
      "url": "storage.js"
    },
    {
      "hash": "sha256-b1D3E9/33XoAnAuJ4vSxfNaEaLghXQsjBaGf7E/wTUI=",
      "url": "video.js"
    }
  ]
};
